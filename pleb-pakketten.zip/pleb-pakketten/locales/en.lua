local Translations = {
    error = {
        ["invalid_items"] = "Je hebt niet de juiste items!",
        ["no_items"] = "Je hebt niet alle items!",
    },
    progress = {
        ["pick_grapes"] = "Bezig met wiet plukken",
        ["process_grapes"] = "Wiet aan het verpakken",
        ["get_brick"] = "Brick aan het verpakken",
    },
    task = {
        ["start_task"] = "~r~[E] Plukken",
        ["brick_proces"] = "~r~[E] Maak brick",
        ["make_weed_bags"] = "~r~[E] Wiet verpakken",
        ['cancel_task'] = "Je hebt het geannuleerd."
    }
}

Lang = Lang or Locale:new({
    phrases = Translations,
    warnOnMissing = true
})
