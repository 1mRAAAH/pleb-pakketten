fx_version 'cerulean'

game 'gta5'

description 'Pleb DPD Pakketten'
author 'Enige Echte 1mRAAAH'

version '1.0'

client_scripts {
	'client/main.lua',
	'config.lua',
	'@PolyZone/client.lua',
	'@PolyZone/BoxZone.lua',
	'@PolyZone/ComboZone.lua',
}

server_scripts {
	'server/main.lua',
	'config.lua',
}
