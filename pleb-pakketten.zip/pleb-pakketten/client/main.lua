QBCore = exports['qb-core']:GetCoreObject()
local onDuty = false
local hasCar = false
local currentGarage = 0
local Blips = {}
local OnJob = false
local Done 	= false
local hasMail = false
local PlayerJob = {}
local nearvan = false
local DeliveriesCount = 0
local inZone = false
local Delivering = false

RegisterNetEvent("qb-dpdpakket:client:SpawnListVehicle",function(data)
    local vehicleSpawnName = data.spawnName
    SpawnListVehicle(vehicleSpawnName)
end)

local function DrawText3Ds(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x,y,z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    PlayerJob = JobInfo
end)


-- CreateBlip
function CreateJobBlip()
     BlipJob = AddBlipForCoord(56.24, -2566.73, 11.74)
                SetBlipSprite(BlipJob, 783)
                SetBlipColour(BlipJob, 59)
                SetBlipScale(BlipJob, 0.6)
                SetBlipDisplay(BlipJob, 4)
                SetBlipAsShortRange(BlipJob, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString("DPD Pakketdienst")
                EndTextCommandSetBlipName(BlipJob)  
end


-- Kies bezorgadres
function SelectAdres()
	local index = GetRandomIntInRange(1,  #Config.Adres)

	for k,v in pairs(Config.Zones) do
		if v.Pos.x == Config.Adres[index].x and v.Pos.y == Config.Adres[index].y and v.Pos.z == Config.Adres[index].z then
			return k
		end
	end
end


-- Create Ped
model = GetHashKey("s_m_m_postal_01")
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(1)
    end

    ped = CreatePed(0, model, 51.26, -2571.42, 5.0, true)
    FreezeEntityPosition(ped, true)
    SetEntityHeading(ped, 358.58)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_CLIPBOARD", 0, true)


-- Spawn Werkauto
function SpawnListVehicle(model)
    local coords = {
        x = 58.18,
        y = -2562.5, 
        z = 5.81,
        w = 0.69
        }
    QBCore.Functions.TriggerCallback('QBCore:Server:SpawnVehicle', function(netId)
        local veh = NetToVeh(netId)
        SetVehicleNumberPlateText(veh, "DPD"..tostring(math.random(0000, 9999)))
        SetEntityHeading(veh, coords.w)
        exports['LegacyFuel']:SetFuel(veh, 100.0)
        TaskWarpPedIntoVehicle(PlayerPedId(), veh, -1)
        TriggerEvent("vehiclekeys:client:SetOwner", QBCore.Functions.GetPlate(veh))
        SetVehicleEngineOn(veh, true, true)
    end, model, coords, true)
    hasCar = true
    StartDelivery() -- Restart Job
end

function VehicleList()
    local vehicleMenu = {
        {
            header = "Vehicle List",
            isMenuHeader = true
        }
    }
    for k,v in pairs(Config.Vehicles) do
        vehicleMenu[#vehicleMenu+1] = {
            header = v,
            txt = "Voertuig: "..v.."",
            params = {
                event = "qb-dpdpakket:client:SpawnListVehicle",
                args = {
                    headername = v,
                    spawnName = k
                }
            }
        }
    end
    vehicleMenu[#vehicleMenu+1] = {
        header = 'Sluiten',
        txt = "",
        params = {
            event = "qb-menu:client:closeMenu"
        }

    }
    exports['qb-menu']:openMenu(vehicleMenu)
end

-- Vind volgende adres
function StartDelivery()
   if DeliveriesCount == 25 then
        QBCore.Functions.Notify('Je bent klaar met bezorgen, je kunt nu uitchecken', 'success')
    else
        DeliveryAdres = SelectAdres()
        local zone = Config.Zones[DeliveryAdres]

        Blips['DeliveryAdres'] = AddBlipForCoord(zone.Pos.x,  zone.Pos.y,  zone.Pos.z)
            SetBlipSprite(Blips['DeliveryAdres'], 12)
            SetBlipColour(Blips['DeliveryAdres'], 59)
            SetBlipScale(Blips['DeliveryAdres'], 0.8)
            SetBlipRoute(Blips['DeliveryAdres'], true)
            SetBlipRouteColour(Blips['DeliveryAdres'], 73)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Bezorgadres")
            EndTextCommandSetBlipName(Blips['DeliveryAdres'])  
            QBCore.Functions.Notify('Adres op GPS')
            Onjob = true
    end
end

function StopDelivery(cancel)

    if Blips['DeliveryAdres'] ~= nil then
		RemoveBlip(Blips['DeliveryAdres'])
		Blips['DeliveryAdres'] = nil
	end
    
	OnJob = false

	if cancel then
        QBCore.Functions.Notify('Geannuleerd', 'error')
	end

end
-- LoadAnim voor animaties
function LoadAnim(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Wait(1)
    end
end

-- Aankomst / Pakket pakken / Bezorgen
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if DeliveryAdres ~= nil then
			local coords = GetEntityCoords(GetPlayerPed(-1))
			local zone   = Config.Zones[DeliveryAdres]
			local player = GetPlayerPed()
            local dist = GetDistanceBetweenCoords(coords, zone.Pos.x, zone.Pos.y, zone.Pos.z, true)

            if dist < 20 then
                inZone = true
            end

                if inZone then
                    local pedpos = GetEntityCoords(GetPlayerPed(-1))
                    local Vehicle = GetClosestVehicle(pedpos, 6.0, 0, 70)
                    local vehPos = GetEntityCoords(Vehicle)
                    local distance = GetDistanceBetweenCoords(pedpos, vehPos)
                        
                        if distance < 4 then
                            NearVan = true
                        end
                    
                        if NearVan and not Hasmail then
                            DrawText3Ds(vehPos.x,vehPos.y,vehPos.z, "[~g~E~s~] Pakket pakken")
                        
                        if IsControlJustReleased(0, 38) then
                            Takemail()
                            NearVan = false
                        end
                        
                        end
                    
                    if dist < 6 then
                        if Delivering == false then
                            DrawText3Ds(zone.Pos.x, zone.Pos.y, zone.Pos.z, "[~g~E~s~] Pakket bezorgen")
                            if dist < 2 then
                                if IsControlJustReleased(0, 38) then
                                    Delivering = true
                                    Takemail()
                                    TriggerEvent('qb-dpdpakket:client:bezorging')
                                end
                            end
                        end
                    end
                end
		end
	end
end)

AddEventHandler('qb-dpdpakket:client:bezorging', function()
    DoorAnim()
    TriggerEvent('qb-sound:client:play', 'house-doorbell', 0.4)
    Wait(2500)                     
    ClearPedTasks(PlayerPedId())
        local rand = math.random(0,100)
        if rand > 0 and rand < 50 then
            schutting()
            else
            bezorgproces()
        end
end)

function loadAnimDict(dict)
	while ( not HasAnimDictLoaded(dict)) do
		RequestAnimDict(dict)
		Citizen.Wait(0)
	end
end

function DoorAnim()
    local ped = PlayerPedId()
    LoadAnim('mp_doorbell')
    TaskPlayAnim(ped, 'mp_doorbell', 'ring_bell_b_left', 6.0, -6.0, -1, 47, 0, 0, 0, 0)
end

function Takemail()
    local player = GetPlayerPed(-1)
    if not IsPedInAnyVehicle(player, false) then
        local ad = "anim@heists@box_carry@"
        local prop_name = 'prop_cs_box_clothes'
        if ( DoesEntityExist( player ) and not IsEntityDead( player )) then
            loadAnimDict( ad )
            if Hasmail then
                TaskPlayAnim( player, ad, "exit", 3.0, 1.0, -1, 49, 0, 0, 0, 0 )
                DetachEntity(prop, 1, 1)
                DeleteObject(prop)
                ClearPedSecondaryTask(PlayerPedId())
                Hasmail = false
            else
                local x,y,z = table.unpack(GetEntityCoords(player))
                prop = CreateObject(GetHashKey(prop_name), x, y, z+0.2,  true,  true, true)
                AttachEntityToEntity(prop, player, GetPedBoneIndex(player, 60309), 0.2, 0.08, 0.2, -45.0, 290.0, 0.0, true, true, false, true, 1, true)
                TaskPlayAnim( player, ad, "idle", 3.0, -8, -1, 63, 0, 0, 0, 0 )
                Hasmail = true
            end
        end
    end
end


function bezorgproces()
    ExecuteCommand("e argue2")
    QBCore.Functions.Progressbar("bezorgen", 'Pakket bezorgen', 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
		StopDelivery()
            -- Rewards
        DeliveriesCount = DeliveriesCount + 1
		TriggerServerEvent('qb-pakketdienst:server:pakketbezorgd:payment')
            ClearPedTasks(PlayerPedId())
            Wait(100)
            Delivering = false
            StartDelivery()
        end, function() -- Cancel
        StopDelivery()
        ClearPedTasks(PlayerPedId())
        QBCore.Functions.Notify('Geannuleerd', 'error')
        Delivering = false
        Wait(100)
        StartDelivery() -- Restart Job
    end)
end
    

function schutting()
    ExecuteCommand("e wave4")
    TriggerEvent('qb-sound:client:play', 'breaking-glass', 0.4)
    QBCore.Functions.Progressbar("bezorgen", 'Over de schutting flikkeren!', 1500, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true,
    }, {}, {}, {}, function() -- Done
        Wait(100)
		StopDelivery()
            -- Rewards
        DeliveriesCount = DeliveriesCount + 1
		TriggerServerEvent('qb-pakketdienst:server:pakketbezorgd:payment')
            ClearPedTasks(PlayerPedId())
            Wait(100)
            Delivering = false
            StartDelivery()
        end, function() -- Cancel
        ClearPedTasks(PlayerPedId())
		StopDelivery()
        Wait(100)
        QBCore.Functions.Notify('Geannuleerd', 'error')
        Delivering = false
        StartDelivery() -- Restart Job
    end)
end

-- Auto pakken/inleveren
Citizen.CreateThread(function()
    CreateJobBlip()  
    while true do
        Wait(0)
        local player = PlayerPedId()
        local pos = GetEntityCoords(player)
        local garage = vector3(58.05, -2563.04, 6.0)
        local isInside = false              
        local vehicle = GetVehiclePedIsIn(player)
        local model = GetEntityModel(vehicle)
            
            if #(pos - garage) < 6 then
                isInside = true
              else
                Wait(1000)
            end
                if QBCore.Functions.GetPlayerData().job and QBCore.Functions.GetPlayerData().job.name == 'dpd' then               
                    if isInside then 
                        --DrawMarker(20, 54.2, -2569.42, 6.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.2, 0.2, 10, 255, 100, 155, false, false, false, true, false, false, false)
                            if not hasCar then
                                if QBCore.Functions.GetPlayerData().job.onduty then
                                    exports['qb-core']:DrawText(' [E] Garage', 'left')

                                    if IsControlJustReleased(0, 38) then
                                         VehicleList()
                                    end
                                end                            
                            else
                            exports['qb-core']:DrawText('[E] Auto inleveren', 'left')
                                        if IsControlJustReleased(0, 38) then
                                            if isInside and hasCar then
                                        print(GetEntityModel(vehicle))
                                        print(GetVehiclePedIsIn(vehicle))

                                                 if model == -2086446273 then
                                                    DeleteVehicle(vehicle)
                                                    hasCar = false       
                                                    QBCore.Functions.Notify('Werkauto ingeleverd', 'success')                             
                                                        if Blips['NPCTargetAdres'] ~= nil then
                                                            RemoveBlip(Blips['NPCTargetAdres'])
                                                            Blips['NPCTargetAdres'] = nil
                                                        end
                                                    onDuty = false
                                                else
                                                    QBCore.Functions.Notify('Dit is geen bedrijfsauto', 'error') 
                                                end     
                                            else
                                                isInside = false
                                                QBCore.Functions.Notify('Parkeer je auto dichterbij', 'error') 
                                            end
                                        end
                            end

                    else
                            exports['qb-core']:HideText()
                    end
                end
        end --end while 
end)