local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('qb-pakketdienst:server:pakketbezorgd:payment')
AddEventHandler('qb-pakketdienst:server:pakketbezorgd:payment', function()
	local _source = source
	local Player = QBCore.Functions.GetPlayer(_source)
    rand1 = math.random(1,100)
    tipamount = math.random(20,50)
    
    Player.Functions.AddMoney("cash", 20, "pakket_bezorgd")
        
    if rand1 == 50 then
        Player.Functions.AddMoney("cash", 250, "pakket_tip")
        TriggerClientEvent("QBCore:Notify", _source, "Bonus ontvangen van €250!!", "success")
    end
end)